#include <iostream>
#include <sstream>
#include "roster.h"

using namespace std;


void Roster::add(string studentID, string firstName, string lastName, string emailAddress, int age, int daysInCourse1, int daysInCourse2, int daysInCourse3, Degree degreeProgram)
{
	int daysInCourse[3] = { daysInCourse1, daysInCourse2, daysInCourse3 };

	for (int i = 0; i < sizeof(classRosterArray) / sizeof(classRosterArray[i]); i++) {
		if (classRosterArray[i] == nullptr) {
			if (degreeProgram == NETWORKING) {
				classRosterArray[i] = new NetworkStudent(age, daysInCourse, studentID, emailAddress, firstName, lastName, degreeProgram);
			}
			else if (degreeProgram == SECURITY) {
				classRosterArray[i] = new SecurityStudent(age, daysInCourse, studentID, emailAddress, firstName, lastName, degreeProgram);
			}
			else if (degreeProgram == SOFTWARE) {
				classRosterArray[i] = new SoftwareStudent(age, daysInCourse, studentID, emailAddress, firstName, lastName, degreeProgram);
			}
			else {
				classRosterArray[i] = new Student(age, daysInCourse, studentID, emailAddress, firstName, lastName, degreeProgram);
			}
			
			break;
		}
	}
}

void Roster::remove(string studentID)
{
	bool removed = false;
	for (int i = 0; i < sizeof(classRosterArray) / sizeof(classRosterArray[i]); i++) {
		if (classRosterArray[i] != nullptr && classRosterArray[i]->getStudentId() == studentID) {
			classRosterArray[i] = nullptr;
			removed = true;
			break;
		}
	}

	if (removed == false) {
		cout << "ERROR: Student ID '" << studentID << "' does not exist \n";
	}
}

void Roster::printAll()
{
	cout << "Displaying roster:" << '\n';
	cout << endl;
	for (int i = 0; i < 5; i++) {
		(*classRosterArray[i]).print();
	}
}

//Prints average nuber of days to the nearest whole number
void Roster::printDaysInCourse(string studentID)
{
	for (int i = 0; i < 5; i++) {
		if ((*classRosterArray[i]).getStudentId() == studentID) {
			int avg = 0;
			avg = ((*classRosterArray[i]).getDaysInCourse()[0] + (*classRosterArray[i]).getDaysInCourse()[1]
				+ (*classRosterArray[i]).getDaysInCourse()[2]) / 3;
			cout << "The average days it took the student with studentID: " << studentID << " to finish 3 courses: " << avg << '\n';
			break;
		}
	}
}

void Roster::printByDegreeProgram(int degreeProgram)
{
	for (int i = 0; i < sizeof(classRosterArray) / sizeof(classRosterArray[i]); i++) {
		if (classRosterArray[i]->getDegreeProgram() == degreeProgram) {
			classRosterArray[i]->print();
		}
	}
}

//Assumes all emails are invalid and then checks for specific characters for validation
void Roster::printInvalidEmails()
{
	cout << "The emails below are invalid: \n";
	for (int i = 0; i < sizeof(classRosterArray) / sizeof(classRosterArray[i]); i++) {
		string email = classRosterArray[i]->getEmail();
		bool valid = false;
		size_t found = email.find("@");
		if (found != string::npos) {
			found = email.find(".");
			if (found != string::npos) {
				found = email.find(" ");
				if (found == string::npos) {
					valid = true;
				}
			}
		}

		if (!valid) {
			cout << "\t\t\t\t" << email << "\n";
		}
	}
}

int main() {
	cout << "Course: Scripting and Programming - Applications - C867 \n";
	cout << "Language: C++ \n";
	cout << "Student ID: 001109630 \n";
	cout << "Student Name: Dustin Rose \n\n";

	Roster classRoster;

	const string studentData[] =
	{
		"A1,John,Smith,John1989@gm ail.com,20,30,35,40,SECURITY",
		"A2,Suzan,Erickson,Erickson_1990@gmailcom,19,50,30,40,NETWORK",
		"A3,Jack,Napoli,The_lawyer99yahoo.com,19,20,40,33,SOFTWARE",
		"A4,Erin,Black,Erin.black@comcast.net,22,50,58,40,SECURITY",
		"A5,Dustin,Rose,drose68@wgu.edu,33,19,15,20,SOFTWARE"
	};

	//populating class roster array
	for (int i = 0; i < sizeof(studentData) / sizeof(studentData[i]); i++) {
		string input = studentData[i];
		istringstream ss(input);
		string token;
		string placeHolder[9];

		int x = 0;
		while (getline(ss, token, ',')) {
			placeHolder[x] = token;
			x += 1;
		}

		enum Degree myDegree;
		if (placeHolder[8] == "NETWORK") {
			myDegree = NETWORKING;
		}
		if (placeHolder[8] == "SECURITY") {
			myDegree = SECURITY;
		}
		if (placeHolder[8] == "SOFTWARE") {
			myDegree = SOFTWARE;
		}

		classRoster.add(placeHolder[0], placeHolder[1], placeHolder[2], placeHolder[3], std::stoi(placeHolder[4]), std::stoi(placeHolder[5]), std::stoi(placeHolder[6]), std::stoi(placeHolder[7]), myDegree);
	}

	classRoster.printAll();
	cout << "\n";
	classRoster.printInvalidEmails();
	cout << "\n";
	for (int i = 0; i < sizeof(classRoster.classRosterArray) / sizeof(classRoster.classRosterArray[i]); i++) {
		classRoster.printDaysInCourse(classRoster.classRosterArray[i]->getStudentId());
	}
	cout << "\n";
	classRoster.printByDegreeProgram(SOFTWARE);
	cout << "\n";
	classRoster.remove("A3");
	classRoster.remove("A3");

	return 0;
}

//Deconstructor
Roster::~Roster()
{

}
