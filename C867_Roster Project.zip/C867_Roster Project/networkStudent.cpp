#include "networkStudent.h"

Degree NetworkStudent::getDegreeProgram()
{
	return DegreeType;
}
