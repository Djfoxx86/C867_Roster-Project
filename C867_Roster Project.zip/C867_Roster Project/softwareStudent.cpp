#include "softwareStudent.h"

Degree SoftwareStudent::getDegreeProgram()
{
	return DegreeType;
}
