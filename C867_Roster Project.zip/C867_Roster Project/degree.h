#pragma once
enum Degree {
	SECURITY,
	NETWORKING,
	SOFTWARE,
	OTHER
};